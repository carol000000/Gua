# -*- coding: utf-8 -*-
import asyncio
import pygame
import os
import random


FPS = 60
h = 1500  
w = 800  
bg = (96, 152, 44)  
gamename = "Poop Game"


p1s = 5  
p2s = 2  



class Player(pygame.sprite.Sprite):
    def __init__(self, img):
        super().__init__()
        self.image = img
        self.rect = self.image.get_rect()
        self.rect.x = 750
        self.rect.y = 400

    def update(self):
        key_pressed = pygame.key.get_pressed()
        if key_pressed[pygame.K_w]: self.rect.y -= p1s
        if key_pressed[pygame.K_s]: self.rect.y += p1s
        if key_pressed[pygame.K_a]: self.rect.x -= p1s
        if key_pressed[pygame.K_d]: self.rect.x += p1s


        if self.rect.left > h: self.rect.right = 0
        elif self.rect.right < 0: self.rect.left = h
        if self.rect.top > w: self.rect.bottom = 0
        elif self.rect.bottom < 0: self.rect.top = w

class Poop(pygame.sprite.Sprite):
    def __init__(self, img, target):
        super().__init__()
        self.image = img
        self.rect = self.image.get_rect()
        self.rect.x = random.randint(0, h)
        self.rect.y = random.randint(0, w)
        self.target = target 

    def update(self):
        px = self.target.rect.x - self.rect.x
        py = self.target.rect.y - self.rect.y
        pxy = ((px**2) + (py**2))**0.5

        if pxy != 0:
            p2x = px / pxy
            p2y = py / pxy
            self.rect.x += round(p2x) * p2s
            self.rect.y += round(p2y) * p2s

class Bullet(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = pygame.Surface((10, 10))
        self.image.fill((255, 255, 255))
        self.rect = self.image.get_rect()


async def main():
    pygame.init()
    screen = pygame.display.set_mode((h, w))
    pygame.display.set_caption(gamename)
    clock = pygame.time.Clock()

    try:
        playerImg = pygame.image.load(os.path.join("pygame", "img", "player01.png")).convert_alpha()
        poopImg = pygame.image.load(os.path.join("pygame", "img", "poop.png")).convert_alpha()
    except Exception as e:
        print(f"圖片載入失敗，請檢查路徑: {e}")
        
        playerImg = pygame.Surface((50, 50))
        playerImg.fill((0, 0, 255))
        poopImg = pygame.Surface((40, 40))
        poopImg.fill((139, 69, 19))

   
    all_sprites = pygame.sprite.Group()
    player = Player(playerImg)
    poop = Poop(poopImg, player)
    bullet = Bullet()
    
    all_sprites.add(player)
    all_sprites.add(poop)
    all_sprites.add(bullet)

    running = True
    
    
    while running:
       
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

       
        all_sprites.update()

        
        screen.fill(bg)
        all_sprites.draw(screen)
        pygame.display.update()

       
        await asyncio.sleep(0) 
        clock.tick(FPS)

    pygame.quit()

# 執行遊戲
if __name__ == "__main__":
    asyncio.run(main())